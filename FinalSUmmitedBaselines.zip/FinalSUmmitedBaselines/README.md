First load the test data set and load the  pretrained model from the google drive

link is :-https://drive.google.com/drive/folders/1DOu99Y8G4x4Nt8uJDVjMEHzyle5Ujm1s
and change the path in the code for the dataset and then model as your pc location 

and then run the code and also install the necessary libary 
like bert_score 
evaluate 

and then run the code and make sure not run the train funcion call

